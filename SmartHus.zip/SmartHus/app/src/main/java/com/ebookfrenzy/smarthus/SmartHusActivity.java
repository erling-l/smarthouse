package com.ebookfrenzy.smarthus;
/*
 * SmartHus 2017-12-20
 * Erling.Lindholm@spray.se
 *
 * ” Smarthus App”
 * Studenten ska skapa en app som ska kommunicera med ett smarthus (Arduino ska med
 * hjälp av olika komponenter simulera lampor, dörrar, alarm, mm på ett hus).
 *
 * För betyg 3:  Studenten bestämmer själv utseendet på Android appen.  Appen ska
 * kunna göra följande på Arduinon: o Tända och släcka lampor i 3 rum i huset. o Appen
 * ska visa temperatur, som simuleras av att använda potentiometer på Arduino. (Om
 * studenten har en temperatur sensor går det bra att använda den istället)  Studenten
 * ska hitta relevant vetenskaplig artikel. Dessa frågor ska bl a besvaras i rapporten:
 * o Vad handlar din artikel om? o Diskutera vilken metod användes i artikeln, för att
 * komma fram till resultatet. o Vad blev resultat? o På vilket sätt kopplas artikeln
 * till projektuppgiften?
 *
 * För betyg 4:  Alla krav för betyg 3 ska vara uppfyllda.  På Arduino, använd knappar
 * för att simulera följande: o Fönster öppen/stängd o Larm på/av  Uppdatera Android
 * appen med de olika signalvärden som man får från Arduino, dvs. visa i appen (med text)
 * att fönster är öppen/stängd, eller att larm är på/av.
 *
 * För betyg 5:  Alla krav för betyg 4 ska vara uppfyllda.  Istället för knappar på
 * Android appen, ska rösten användas till att styra vad som ska hända i huset.  När
 * du får tillbaka meddelande från Arduino, ska telefonen också vibrera.
 */
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.Set;

import static java.util.UUID.fromString;

public class SmartHusActivity extends AppCompatActivity {

    private static final String TAG = "Bt-AndroidActivity";
    private static final int REQUEST_ENABLE_BT = 42;
    // Well-known UUID för Serial profile
    // https://www.bluetooth.com/specifications/assigned-numbers/service-discovery
    static final String MY_UUID = "00001101-0000-1000-8000-00805F9B34FB";
    private BroadcastReceiver mReceiver;
    BluetoothDevice myDevice;
    String mydeviceHardwareAddress;
    BluetoothAdapter mBluetoothAdapter;
    ConnectedThread myConnectedThread;
    MyHandler mHandler;

    //static inner class doesn't hold an implicit reference to the outer class
    private static class MyHandler extends Handler {
        //Using a weak reference means you won't prevent garbage collection
        private final WeakReference<SmartHusActivity> myClassWeakReference;

        public MyHandler(SmartHusActivity myClassInstance) {
            myClassWeakReference = new WeakReference<SmartHusActivity>(myClassInstance);
        }

        @Override
        public void handleMessage(Message msg) {
            SmartHusActivity sm = myClassWeakReference.get();

            if (sm != null) {
                switch (msg.what) {
                    case MessageConstants.MESSAGE_READ:
                        sm.doUpdateRead(msg);
                        break;
                    case MessageConstants.MESSAGE_WRITE:
                        sm.doUpdateWrite(msg);
                        break;
                    case MessageConstants.MESSAGE_TOAST:
                        sm.doUpdate(msg);
                        break;
                }


            }
        }
    }


    private void doUpdate(Message m) {
//        TextView myTextView = (TextView)findViewById(R.id.alarm);;
//        myTextView.setText("I've been updated." + m.toString());
        Log.i(TAG, "MSGUpdated");
    }
    private void doUpdateRead(Message m) {
//        TextView myTextView2 = (TextView)findViewById(R.id.textDebug);
//        myTextView2.append(" M " + m.arg1 + " " + m.arg2);
        ToggleButton t;





            TextView myTextView = (TextView) findViewById(R.id.temp1);
        if (m.arg1 == 3) {
            myTextView.setText(String.valueOf(m.arg2));
        } else if (m.arg1 == 6) {
            myTextView = (TextView) findViewById(R.id.temp2);
            myTextView.setText(String.valueOf(m.arg2));
        } else if (m.arg1 == 10) {
            myTextView = (TextView) findViewById(R.id.temp3);
            myTextView.setText(String.valueOf(m.arg2));
        } else if (m.arg1 == 1) {
            char c = (char) m.arg2;

// Vibrate for 500 milliseconds
                vibrate(500);
//                TextView myTextView1 = (TextView) findViewById(R.id.textDebug);
//            myTextView1.append("I" + m.toString() + " " + c);
                switch (c) {
                    case '4':
                        myTextView = (TextView) findViewById(R.id.alarm);
                        myTextView.setText(R.string.alarmon);
                        break;
                    case 'd':
                        myTextView = (TextView) findViewById(R.id.alarm);
                        myTextView.setText(R.string.alarmoff);
//                    Toast.makeText(getApplicationContext(), "Command d" , Toast.LENGTH_LONG).show();
                        break;
                    case '5':
                        myTextView = (TextView) findViewById(R.id.window1);
                        myTextView.setText(R.string.open);
                        break;
                    case 'e':
                        myTextView = (TextView) findViewById(R.id.window1);
                        myTextView.setText(R.string.close);
//                    Toast.makeText(getApplicationContext(), "Command e" , Toast.LENGTH_LONG).show();
                        break;
                    case '6':
                        myTextView = (TextView) findViewById(R.id.window2);
                        myTextView.setText(R.string.open);
                        break;
                    case 'f':
                        myTextView = (TextView) findViewById(R.id.window2);
                        myTextView.setText(R.string.close);
//                        Toast.makeText(getApplicationContext(), "Command f", Toast.LENGTH_LONG).show();
                        break;
                    case '7':
                        myTextView = (TextView) findViewById(R.id.window3);
                        myTextView.setText(R.string.open);
                        break;
                    case 'g':
                        myTextView = (TextView) findViewById(R.id.window3);
                        myTextView.setText(R.string.close);
                        break;
                    case '1':
                        t = (ToggleButton) findViewById(R.id.lampa1);
                        t.setChecked(true);
                    Log.i(TAG, "L " + t.isChecked());
//                        Toast.makeText(getApplicationContext(), "Command 1" , Toast.LENGTH_LONG).show();
                        break;
                    case 'a':
                        t = (ToggleButton) findViewById(R.id.lampa1);
                        t.setChecked(false);
                        Log.i(TAG, "LL " + t.isChecked());
//                    Toast.makeText(getApplicationContext(), "Command a" , Toast.LENGTH_LONG).show();
                        break;
                    case '2':
                        t = (ToggleButton) findViewById(R.id.lampa2);
                        t.setChecked(true);
                        break;
                    case 'b':
                        t = (ToggleButton) findViewById(R.id.lampa2);
                        t.setChecked(false);
//                        Toast.makeText(getApplicationContext(), "Command b", Toast.LENGTH_LONG).show();
                        break;
                    case '3':
                        t = (ToggleButton) findViewById(R.id.lampa3);
                        t.setChecked(true);
                        break;
                    case 'c':
                        t = (ToggleButton) findViewById(R.id.lampa3);
                        t.setChecked(false);
                        break;
                    default:
//                    myTextView = (TextView) findViewById(R.id.alarm);
//                    myTextView.setText("received" + m.arg2);
                        break;

                }
            }

    }
    private void doUpdateWrite(Message m) {
//        TextView myTextView = (TextView)findViewById(R.id.alarm);
//        myTextView.setText("sent" + m.arg2);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_hus);
        mHandler = new MyHandler(this);
        Log.i(TAG, "onCreate");
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Check and enable bluetooth
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
        } else {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

            if (pairedDevices.size() > 0) {
                // There are paired devices. Get the name and address of each paired device.
                for (BluetoothDevice device : pairedDevices) {
                    String deviceName = device.getName();
                    String deviceHardwareAddress = device.getAddress(); // MAC address
                    if (deviceName.equalsIgnoreCase("HC-06")) {
                        myDevice = device;
                        mydeviceHardwareAddress = deviceHardwareAddress;
                    }
                }
            }
            // Register for broadcasts when a device is discovered.
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            Intent intent = registerReceiver(mReceiver, filter);


            // Create a BroadcastReceiver for ACTION_FOUND

            mReceiver = new BroadcastReceiver() {
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                        // Discovery has found a device. Get the BluetoothDevice
                        // object and its info from the Intent.
                        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        String deviceName = device.getName();
                        String deviceHardwareAddress = device.getAddress(); // MAC address
                        if (deviceName.equalsIgnoreCase("HC-06")) {
                            myDevice = device;
                            mydeviceHardwareAddress = deviceHardwareAddress;

                        }
                    }
                }
            };


//            FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//            fab.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                            .setAction("Action", null).show();
//                }
//            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_smart_hus, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");


        // Don't forget to unregister the ACTION_FOUND receiver.
        unregisterReceiver(mReceiver);
    }

    public void voiceToggle(View v) {
        String text = "4";
        byte[] cmd;
        cmd = text.getBytes();
//        Toast.makeText(getApplicationContext(), "Command 4" + cmd.length, Toast.LENGTH_LONG).show();
        myConnectedThread.write(cmd);
    }
    public void vibrate(int duration)
    {
        Vibrator vibs = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibs.vibrate(duration);
    }
   public void lampa1(View v) {
        boolean on = ((ToggleButton) v).isChecked();
        String text;
        if (on) {
            text = "1";
        } else {
            text = "a";
        }
        byte[] cmd;
        cmd = text.getBytes();
        myConnectedThread.write(cmd);
//        Toast.makeText(getApplicationContext(), "Command 1 " + cmd.length, Toast.LENGTH_LONG).show();
    }

    public void lampa2(View v) {
        boolean on = ((ToggleButton) v).isChecked();
        String text;
        if (on) {
            text = "2";
        } else {
            text = "b";
        }
        byte[] cmd;
        cmd = text.getBytes();
        myConnectedThread.write(cmd);
//        Toast.makeText(getApplicationContext(), "Command 2 " + cmd.length, Toast.LENGTH_LONG).show();
    }

    public void lampa3(View v) {
        boolean on = ((ToggleButton) v).isChecked();
        String text;
        if (on) {
            text = "3";
        } else {
            text = "c";
        }
        byte[] cmd;
        cmd = text.getBytes();
        myConnectedThread.write(cmd);
//        Toast.makeText(getApplicationContext(), "Command 3 " + cmd.length, Toast.LENGTH_LONG).show();
    }

    public void pairBT(View v) {
        ConnectThread connectThread = new ConnectThread(myDevice);
        connectThread.run();
//        connectThread.start();
    }
    public void unPairBT(View v) {
        myConnectedThread.cancel();
    }
    public void manageMyConnectedSocket(BluetoothSocket b) {
//        TextView myTextView = (TextView)findViewById(R.id.alarm);
//        myTextView.setText(R.string.startSocket);
//        Toast.makeText(getApplicationContext(),"managed " + myDevice.getName(), Toast.LENGTH_LONG).show();
        myConnectedThread =new ConnectedThread(b);
        myConnectedThread.start();
        String text;
            text = "s";
        byte[] cmd;
        cmd = text.getBytes();
        myConnectedThread.write(cmd);
//        Toast.makeText(getApplicationContext(), "Command 3 " + cmd.length, Toast.LENGTH_LONG).show();

    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        ConnectThread(BluetoothDevice device) {
            // Use a temporary object that is later assigned to mmSocket
            // because mmSocket is final.
            BluetoothSocket tmp = null;
            mmDevice = device;

            try {
                // Get a BluetoothSocket to connect with the given BluetoothDevice.
                // MY_UUID is the app's UUID string, also used in the server code.
                tmp = device.createRfcommSocketToServiceRecord(fromString(MY_UUID));
            } catch (IOException e) {
                Log.e(TAG, "Socket's create() method failed", e);
            }
            mmSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it otherwise slows down the connection.
            mBluetoothAdapter.cancelDiscovery();

            try {
                // Connect to the remote device through the socket. This call blocks
                // until it succeeds or throws an exception.
                mmSocket.connect();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and return.
                try {
                    mmSocket.close();
                } catch (IOException closeException) {
                    Log.e(TAG, "Could not close the client socket", closeException);
                }
                return;
            }

            // The connection attempt succeeded. Perform work associated with
            // the connection in a separate thread.
            manageMyConnectedSocket(mmSocket);
        }

        // Closes the client socket and causes the thread to finish.
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Could not close the client socket", e);
            }
        }
    }

    // Defines several constants used when transmitting messages between the
    // service and the UI.
    private interface MessageConstants {
        public static final int MESSAGE_READ = 0;
        public static final int MESSAGE_WRITE = 1;
        public static final int MESSAGE_TOAST = 2;

        // ... (Add other message types here as needed.)
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmLocalSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private byte[] mmBuffer; // mmBuffer store for the stream

        ConnectedThread(BluetoothSocket socket) {
            mmLocalSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams; using temp objects because
            // member streams are final.
            try {
                tmpIn = socket.getInputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error occurred when creating input stream", e);
            }
            try {
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "Error occurred when creating output stream", e);
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            int i =0;
            int c;
            boolean cancel = false;
            mmBuffer = new byte[1024];
            int numBytes = 0; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs.
            while (true) {
                try {
                    cancel = false;
                    numBytes = 0;
//                    Log.i(TAG, "M " + numBytes);
                    // Read from the InputStream.
                    while (!cancel) {
                        c = mmInStream.read(mmBuffer,i,1);
                        if (c != -1 && mmBuffer[i] != '\r') {
//                            mmBuffer[i] = (byte) c;
                            i++;
//                            Log.i(TAG, "I " + i);
                        } else {
                            numBytes = i;
                            i =0;
                            cancel = true;
                        }

                    }
//                    mmBuffer[0] = 0;
//                    mmBuffer[1] = 0;
//                    numBytes = mmInStream.read(mmBuffer);
//                    Log.i(TAG, "N " + numBytes + " " + mmBuffer[0] + " " + mmBuffer[1] + " " + mmBuffer[2] + " " + mmBuffer[3] + " " + mmBuffer[4]);
                    Bundle bundle = new Bundle();
                    bundle.putByteArray("rec",mmBuffer);
                    // Send the obtained bytes to the UI activity.
                    Message readMsg = mHandler.obtainMessage(
                            MessageConstants.MESSAGE_READ, numBytes, mmBuffer[0],
                            bundle);
                    readMsg.sendToTarget();
                } catch (IOException e) {
                    Log.d(TAG, "Input stream was disconnected", e);
                    break;
                }
            }
        }

        // Call this from the main activity to send data to the remote device.
        void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);
                Bundle bundle = new Bundle();
                bundle.putByteArray("transmit",bytes);
                // Share the sent message with the UI activity.
                Message writtenMsg = mHandler.obtainMessage(
                        MessageConstants.MESSAGE_WRITE, -1, bytes[0],
                        bundle);

                writtenMsg.sendToTarget();
            } catch (Exception e) {
                Log.e(TAG, "Error occurred when sending data", e);

                // Send a failure message back to the activity.
                Message writeErrorMsg =
                        mHandler.obtainMessage(MessageConstants.MESSAGE_TOAST);
                Bundle bundle = new Bundle();
                bundle.putString("toast",
                        "Couldn't send data to the other device");
                writeErrorMsg.setData(bundle);
                mHandler.sendMessage(writeErrorMsg);
            }
        }

        // Call this method from the main activity to shut down the connection.
        void cancel() {
            try {
                mmLocalSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Could not close the connect socket", e);
            }
        }
    }

}
